//  Audio Player 0.5 by RAF (Google) 

var Again = 0;
var Exp = 'mp3';
var PlayerID = 'SwfPlayer';
var PlayerData = '/player/uppod.swf';
var PlayerST = '/player/audio70-1149.txt';
var PlayerWidth = 320;
var PlayerHieght = 40;

// Class & Id's
var Close = [ "#PlayersClose", "PlayersClose", 'BottonClose' ]
var Play = [ "#Play", "Play", 'BottonPlay' ]
var Pause = [ "#Pause", "Pause", 'BottonPause' ]
var Stop = [ "#Stop", "Stop", 'BottonStop' ]
var Next = [ "#Next", "Next", 'BottonNext' ]
var Prev = [ "#Prev", "Prev", 'BottonPrev' ]
var DL = [ "#Download", "Download", 'BottonDownload' ]
var Poster = [ "#Poster", "Poster", 'Poster' ]

var BtClick = [ '#Player', 'Player' ];
var html = '#SwfPlayerv';

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('9(1f T==\'1g\'){l T=0}h 1h(a,b){l c=a-1;l d=+a+1;l y=a-2;l z=a-3;l A=a-4;l E=a-5;$(q[0]).6(h(){F(B,\'U\')});$(r[0]).6(h(){F(B,\'Y\')});$(C[0]).6(h(){F(B,\'Z\')});$(G[0]).6(h(){9(m.n(7[1]+c)){$(7[0]+c).6()}i 9(m.n(7[1]+y)){$(7[0]+y).6()}i 9(m.n(7[1]+z)){$(7[0]+z).6()}i 9(m.n(7[1]+A)){$(7[0]+A).6()}i 9(m.n(7[1]+E)){$(7[0]+E).6()}});$(H[0]).6(h(){$(7[0]+d).6()});9(j<1){$(\'#j\').6(h(){j=1;$(10).11({12:\'1\'})})}i{$(\'#j\').6(h(){j=0;$(10).11({12:\'0.4\'})})}$(I[0]).6(h(){$(C[0]).6();$(J).K({L:\'-13\',M:\'14\'},{N:O,P:Q});$(s[0]).K({L:\'-13\',M:\'14\'},{N:O,P:Q});j=0});1i(b){R"1j":$(q[0]).D();$(r[0]).t();1k(h(){9(j==1){F(B,\'U\')}i 9(m.n(7[1]+c)){$(7[0]+c).6()}i 9(m.n(7[1]+y)){$(7[0]+y).6()}i 9(m.n(7[1]+z)){$(7[0]+z).6()}i 9(m.n(7[1]+A)){$(7[0]+A).6()}i{$(7[0]+E).6()}},1l);S;R"U":$(q[0]).t();$(r[0]).D();S;R"Z":$(q[0]).D();$(r[0]).t();S;R"Y":$(q[0]).D();$(r[0]).t();S}};h 1m(a,b,c,d,e){$(J).K({L:\'15\',M:\'\'},{N:O,P:Q});9(T>0){l V=\'\'+1n+\'?1o=\'+b+\'&u=\'+a+\'&f=\'+1p+\'\'}i{l V=d};$(J).J(\'<16 1q="0" 1r="0" 1s="0" W="17"><18><8><g k="\'+H[1]+\'"></g></8><8><g k="\'+q[1]+\'"></g><g k="\'+r[1]+\'"></g></8><8><g k="j"></g></8><8><g k="\'+C[1]+\'"></g></8><8><g k="\'+G[1]+\'"></g></8><8><19 k="\'+B+\'" 1t="1u/x-1v-1w" 1x="\'+1a+\'" 1b="\'+1y+\'" W="\'+1z+\'"><v w="#1A" /><v u="1B" w="1C" /><v u="1D" w="1E" /><v u="1F" w="1G" /><v u="1H" w="\'+1a+\'" /><v u="1I" w="1J=\'+c+\'&1K=\'+a+\'&1L=\'+1M+\'&1N;1O=\'+b+\'" /></19></8><8><a k="\'+X[1]+\'" 1P="\'+V+\'"></a></8><8 1Q="1c" 1R="1S-1c:1T;"><g k="\'+I[1]+\'"></g></8></18></16><1d k="\'+s[1]+\'"><1U 1V="\'+e+\'" 1b="17" W="1W"></1d>\');j=0;1e();$(s[0]).K({L:\'15\',M:\'\'},{N:O,P:Q});9(e){$(s[0]).D()}};h 1e(){$(I[0]).o(\'p\',I[2]);$(q[0]).o(\'p\',q[2]).t();$(r[0]).o(\'p\',r[2]);$(C[0]).o(\'p\',C[2]);$(\'#j\').o(\'p\',\'1X\');$(G[0]).o(\'p\',G[2]);$(H[0]).o(\'p\',H[2]);$(X[0]).o(\'p\',X[2]);$(s[0]).o(\'p\',s[2]).t()};',62,122,'||||||click|BtClick|td|if|||||||font|function|else|Again|id|var|document|getElementById|attr|class|Play|Pause|Poster|hide|name|param|value||c2|c3|c4|PlayerID|Stop|show|c5|uppodSend|Next|Prev|Close|html|animate|bottom|display|queue|false|duration|350|case|break|DownSTR|play|DownLoad|height|DL|pause|stop|this|css|opacity|50|none||table|44|tr|object|PlayerData|width|top|div|addClass|typeof|undefined|uppodEvent|switch|end|setTimeout|300|Player|phpFile|url|Exp|border|cellpadding|cellspacing|type|application|shockwave|flash|data|PlayerWidth|PlayerHieght|ffffff|allowFullScreen|true|allowScriptAccess|always|wmode|transparent|movie|flashvars|uid|comment|st|PlayerST|amp|file|href|valign|style|padding|5px|img|src|42|BottonAgain'.split('|'),0,{}))

// Copyright 2012 clubs-music.ru & uSite.su
// ��������� �����, ����� �������� � ������������ ������ ��������.
// ��������: Skype:raf-1994, ICQ:566667065, e-Mail: raf@xaker.ru